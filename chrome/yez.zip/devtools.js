chrome.devtools.panels.create(
	"Yez!", 
	"img/icon16.png", 
	"index.html",
	function() {
		
	}
);